<html>
<head>
<title>Corporate Administration Ssytem Logout </title>
</head>


<body bgcolor="#000000">
<center>
<font color="#ffffff">
<p>CORPORATE ADMINISTRATION SYSTEM LOGOUT </p>
<br /><br />
<b><p>Thank you for using the Corporate Administration System</p></b>
<br /><br />

