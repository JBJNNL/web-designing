<html>
<body>
<h1>Track Book Location</h1>

<form action="TrackResult.php" method="post">
<table>
<tr>
    <td>ISBN</td>
    <td><input type="text" name="isbn" required/></td>
</tr>
</table>

<input type="submit" value="Locate"/>
</form>

<form action="UserSummary.php" method="post">
<input type="submit" value="Back"/>
</form>


</body>
</html>