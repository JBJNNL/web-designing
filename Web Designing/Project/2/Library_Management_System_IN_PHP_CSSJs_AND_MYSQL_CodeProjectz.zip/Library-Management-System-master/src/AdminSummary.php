<html>
<body>
<h1>Admin Summary</h1>

<form action="PopularSubjectReport.php" method="post">
<input type="submit" value="Popular Subject Report"/>
</form>

<form action="FrequentUsersReport.php" method="post">
<input type="submit" value="Frequent User Report"/>
</form>

<form action="PopularBooksReport.php" method="post">
<input type="submit" value="Popular Books Report"/>
</form>

<form action="DamagedBooksReport.php" method="post">
<input type="submit" value="Damaged Books Report"/>
</form>

<form action="LostDamagedBook_Admin.php" method="post">
<input type="submit" value="Lost/Damaged Book"/>
</form>

<form action="Login.php" method="post">
<input type="submit" value="Close"/>
</form>

</body>
</html>