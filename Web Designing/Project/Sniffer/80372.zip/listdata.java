/*
 * Struct (in C++ terminology) for List data items.
 */
public class listdata
{
	public String header;
	public String data;
	
	public String toString()
	{
		return header;
	}
}
